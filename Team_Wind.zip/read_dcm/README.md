Output 

![alt text](../images/dicom_output.png?raw=true "Read Dicom Series Output")