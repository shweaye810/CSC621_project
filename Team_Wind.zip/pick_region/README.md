Result

![alt text](../images/region_growing.png?raw=true "Pick region, Region growing Result")
